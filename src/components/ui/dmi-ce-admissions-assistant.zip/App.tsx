
import React, { useState, useCallback } from 'react';
import { Message, Language } from './types';
import { geminiService } from './services/geminiService';
import VoiceController from './components/VoiceController';
import ChatHistory from './components/ChatHistory';
import InfoSidebar from './components/InfoSidebar';
import { GraduationCap, Info } from 'lucide-react';

const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState<Language>('en-US');

  const addMessage = useCallback((role: 'user' | 'assistant', content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      role,
      content,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, newMessage]);
    return newMessage;
  }, []);

  const handleInput = async (text: string) => {
    if (!text.trim() || isProcessing) return;

    addMessage('user', text);
    setIsProcessing(true);

    const history = messages.map(m => ({
      role: (m.role === 'assistant' ? 'model' : 'user') as 'model' | 'user',
      parts: [{ text: m.content }]
    }));

    try {
      const aiResponse = await geminiService.generateResponse(text, history);
      addMessage('assistant', aiResponse || "I didn't quite catch that. Could you repeat?");
    } catch (error) {
      addMessage('assistant', "I'm having some technical trouble. Please try again later.");
    } finally {
      setIsProcessing(false);
    }
  };

  const lastAssistantMessage = messages
    .filter((m) => m.role === 'assistant')
    .slice(-1)[0]?.content;

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 shadow-sm z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
              <GraduationCap size={24} />
            </div>
            <div>
              <h1 className="font-bold text-slate-800 tracking-tight text-lg">DMI CE Admissions</h1>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Assistant Online</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
             <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-xs font-semibold border border-blue-100">
                <Info size={14} />
                2026-27 Admissions
             </div>
          </div>
        </header>

        <main className="flex-1 relative overflow-hidden flex flex-col">
          <div className="flex-1 flex flex-col h-full bg-slate-50/30">
            <div className="flex-1 overflow-y-auto scrollbar-hide">
              <ChatHistory messages={messages} />
            </div>
            
            <div className="p-4 md:p-6 bg-white border-t border-slate-200">
              <div className="max-w-3xl mx-auto w-full">
                <VoiceController 
                  onTranscript={handleInput}
                  lastResponse={lastAssistantMessage}
                  isProcessing={isProcessing}
                  language={currentLanguage}
                  onLanguageChange={setCurrentLanguage}
                />
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Sidebar Desktop */}
      <InfoSidebar />
    </div>
  );
};

export default App;
