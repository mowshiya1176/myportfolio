
export type Language = 'en-US' | 'hi-IN' | 'ta-IN';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface UniversityData {
  universityName: string;
  programs: Program[];
  deadlines: { [key: string]: string };
  contacts: {
    email: string;
    phone: string;
    office: string;
  };
}

export interface Program {
  name: string;
  duration: string;
  fees: string;
  eligibility: string;
  description: string;
}
