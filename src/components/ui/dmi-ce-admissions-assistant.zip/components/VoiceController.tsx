
import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, RefreshCcw, Send } from 'lucide-react';
import { Language } from '../types';

interface VoiceControllerProps {
  onTranscript: (text: string) => void;
  lastResponse?: string;
  isProcessing: boolean;
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

const VoiceController: React.FC<VoiceControllerProps> = ({ 
  onTranscript, 
  lastResponse, 
  isProcessing,
  language,
  onLanguageChange
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(true);
  const [textInput, setTextInput] = useState("");
  
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = language;

      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) onTranscript(transcript);
      };

      recognitionRef.current = recognition;
    }
  }, [onTranscript, language]);

  useEffect(() => {
    if (lastResponse && speechEnabled && !isProcessing) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(lastResponse);
      utterance.lang = language;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      
      const voices = window.speechSynthesis.getVoices();
      const preferredVoice = voices.find(v => v.lang.startsWith(language.split('-')[0]));
      if (preferredVoice) utterance.voice = preferredVoice;

      window.speechSynthesis.speak(utterance);
    }
  }, [lastResponse, speechEnabled, isProcessing, language]);

  const toggleListening = () => {
    if (isListening) {
      recognitionRef.current?.stop();
    } else {
      window.speechSynthesis.cancel();
      recognitionRef.current?.start();
    }
  };

  const handleSendText = () => {
    if (textInput.trim() && !isProcessing) {
      onTranscript(textInput);
      setTextInput("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendText();
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 w-full">
      {/* Language Selector */}
      <div className="flex gap-2">
        {(['en-US', 'hi-IN', 'ta-IN'] as Language[]).map((lang) => (
          <button
            key={lang}
            onClick={() => onLanguageChange(lang)}
            className={`px-3 py-1 text-[10px] font-bold rounded-full transition-all border ${
              language === lang 
                ? 'bg-blue-600 text-white border-blue-600 shadow-sm' 
                : 'bg-white text-slate-500 border-slate-200 hover:border-blue-300'
            }`}
          >
            {lang === 'en-US' ? 'English' : lang === 'hi-IN' ? 'हिन्दी' : 'தமிழ்'}
          </button>
        ))}
      </div>

      {/* Input Bar */}
      <div className="relative w-full max-w-2xl flex items-center gap-2">
        <div className="flex-1 relative">
          <input
            type="text"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={isListening ? "Listening..." : "Type your question here..."}
            className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-6 pr-24 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-slate-700"
            disabled={isProcessing || isListening}
          />
          
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
             <button
              onClick={handleSendText}
              disabled={!textInput.trim() || isProcessing}
              className={`p-2 rounded-xl transition-all ${
                textInput.trim() ? 'bg-blue-600 text-white' : 'text-slate-300'
              }`}
            >
              <Send size={20} />
            </button>
            <div className="w-px h-6 bg-slate-200 mx-1"></div>
            <button
              onClick={toggleListening}
              disabled={isProcessing}
              className={`relative p-2.5 rounded-xl transition-all ${
                isListening 
                  ? 'bg-red-500 text-white recording-pulse' 
                  : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
              }`}
            >
              {isListening ? <MicOff size={20} /> : <Mic size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Audio Controls */}
      <div className="flex items-center gap-4 text-xs font-medium">
        <button 
          onClick={() => setSpeechEnabled(!speechEnabled)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-colors ${speechEnabled ? 'text-blue-600 bg-blue-50' : 'text-slate-400 bg-slate-50'}`}
        >
          {speechEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
          {speechEnabled ? 'Audio On' : 'Audio Off'}
        </button>
        
        {isSpeaking && (
          <button 
            onClick={() => window.speechSynthesis.cancel()}
            className="px-3 py-1.5 text-red-600 bg-red-50 rounded-lg border border-red-100 flex items-center gap-2"
          >
            <RefreshCcw size={14} /> Stop Voice
          </button>
        )}

        {isProcessing && (
          <span className="flex items-center gap-2 text-slate-400">
            <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></span>
            Thinking...
          </span>
        )}
      </div>
    </div>
  );
};

export default VoiceController;
