
import React from 'react';
import { UNIVERSITY_DATA } from '../constants';
import { BookOpen, Calendar, Mail, MapPin, Phone } from 'lucide-react';

const InfoSidebar: React.FC = () => {
  return (
    <div className="hidden lg:flex flex-col gap-6 w-80 p-6 bg-white border-l border-slate-200 overflow-y-auto">
      <div>
        <h2 className="text-xl font-bold text-slate-800 mb-1">{UNIVERSITY_DATA.universityName}</h2>
        <p className="text-xs text-slate-500 font-medium tracking-wide uppercase">Admissions Hub</p>
      </div>

      <section>
        <div className="flex items-center gap-2 text-blue-600 mb-3">
          <Calendar size={18} />
          <h3 className="font-semibold text-sm">Key Dates</h3>
        </div>
        <div className="space-y-3">
          {Object.entries(UNIVERSITY_DATA.deadlines).map(([key, val]) => (
            <div key={key} className="p-3 bg-slate-50 rounded-xl">
              <p className="text-[10px] text-slate-400 uppercase font-bold">{key}</p>
              <p className="text-sm font-medium text-slate-700">{val}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <div className="flex items-center gap-2 text-indigo-600 mb-3">
          <BookOpen size={18} />
          <h3 className="font-semibold text-sm">Popular Programs</h3>
        </div>
        <div className="space-y-2">
          {UNIVERSITY_DATA.programs.slice(0, 3).map((p) => (
            <div key={p.name} className="p-3 border border-slate-100 rounded-xl hover:border-indigo-100 transition-colors">
              <p className="text-sm font-bold text-slate-700">{p.name}</p>
              <p className="text-xs text-slate-500">{p.duration} • {p.fees}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-auto">
        <h3 className="font-semibold text-sm text-slate-800 mb-3">Contact Support</h3>
        <div className="space-y-3">
          <a href={`tel:${UNIVERSITY_DATA.contacts.phone}`} className="flex items-center gap-3 text-sm text-slate-600 hover:text-blue-600 transition-colors">
            <Phone size={16} />
            {UNIVERSITY_DATA.contacts.phone}
          </a>
          <a href={`mailto:${UNIVERSITY_DATA.contacts.email}`} className="flex items-center gap-3 text-sm text-slate-600 hover:text-blue-600 transition-colors">
            <Mail size={16} />
            {UNIVERSITY_DATA.contacts.email}
          </a>
          <div className="flex items-start gap-3 text-sm text-slate-600">
            <MapPin size={16} className="mt-1 flex-shrink-0" />
            <span>{UNIVERSITY_DATA.contacts.office}</span>
          </div>
        </div>
      </section>
    </div>
  );
};

export default InfoSidebar;
