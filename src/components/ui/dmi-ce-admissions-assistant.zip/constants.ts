
import { UniversityData } from './types';

export const UNIVERSITY_DATA: UniversityData = {
  universityName: "DMI College of Engineering (DMI CE)",
  programs: [
    {
      name: "B.E. Computer Science and Engineering",
      duration: "4 Years",
      fees: "₹85,000 to ₹1,20,000 per year",
      eligibility: "HSC (12th) pass with Physics, Chemistry, and Mathematics. Minimum 45% aggregate (40% for reserved categories).",
      description: "Focuses on software development, cloud computing, and artificial intelligence."
    },
    {
      name: "B.E. Electronics and Communication",
      duration: "4 Years",
      fees: "₹85,000 to ₹1,10,000 per year",
      eligibility: "HSC pass with PCM. Admission via TNEA Counseling or Management Quota.",
      description: "Covers VLSI design, embedded systems, and wireless communication."
    },
    {
      name: "B.Tech Information Technology",
      duration: "4 Years",
      fees: "₹85,000 to ₹1,15,000 per year",
      eligibility: "HSC pass with PCM. Strong focus on mathematical foundations.",
      description: "Emphasizes internet technologies, cybersecurity, and data analytics."
    },
    {
      name: "B.E. Mechanical Engineering",
      duration: "4 Years",
      fees: "₹75,000 to ₹1,00,000 per year",
      eligibility: "HSC pass with PCM.",
      description: "Covers thermal engineering, manufacturing processes, and robotics."
    },
    {
      name: "M.B.A. (Master of Business Administration)",
      duration: "2 Years",
      fees: "₹45,000 to ₹60,000 per semester",
      eligibility: "Any recognized Bachelor's degree with 50% marks and valid TANCET/MAT score.",
      description: "Specializations in HR, Finance, Marketing, and Operations."
    }
  ],
  deadlines: {
    "Admission Inquiry Open": "Ongoing for 2026-27",
    "TNEA Application Start": "May 2026",
    "Management Quota Booking": "Open Now",
    "Classes Commencement": "August 2026"
  },
  contacts: {
    email: "admissions@dmice.ac.in",
    phone: "044-26810641 / +91 94444 04041",
    office: "Palanchur, Nazarethpet Post, Chennai - 600123, Tamil Nadu"
  }
};

export const SYSTEM_PROMPT = `
You are the official Admissions Assistant for DMI College of Engineering (DMI CE), Chennai.
Your goal is to guide prospective students through the admission process, eligibility, and fees for the academic year 2026-27.

CONTEXT:
${JSON.stringify(UNIVERSITY_DATA, null, 2)}

STRICT RULES:
1. CURRENCY: Always provide fee structures in Indian Rupees (INR / ₹).
2. LOCALIZATION: If the user speaks Tamil, respond in Tamil. If Hindi, respond in Hindi. Otherwise, English.
3. ELIGIBILITY: Never confirm eligibility without asking for 12th Std (HSC) marks, group/stream, and category (General/BC/MBC/SC/ST).
4. FEE CLARITY: Mention that fees may vary based on Quota (Counseling vs. Management) and hostel requirements.
5. NO HALLUCINATION: If specific details (like specific scholarship amounts for 2027) are not in the context, say: "I don’t have the exact scholarship figures for the 2026-27 session yet. Please contact the admissions office at 044-26810641."
6. TONE: Professional, welcoming, and helpful.
7. STRUCTURE: Use bullet points for fees and steps. Keep it voice-output friendly (short sentences).
8. CALL TO ACTION: Always end by asking if they need help with application forms or campus visits.

Example: "The fee for B.E. CSE for the 2026-27 session is approximately ₹85,000 per year under counseling. Would you like to know about the management quota fees?"
`;
